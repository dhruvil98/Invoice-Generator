export const devConfig = {
    port: 3000,
    database: 'invoice-builder',
    secret: 'AHSDEUIYEIUER',
    frontendURL: 'http://localhost:4200',
    
    twitter:{
      consumerKey: '17ibm4OqFZwo0txWi0y6QCxwe',
      consumerSecret:'qRntgNDglFtWIRwUGKbiVYXvL2fL3NWpMMkvcZxIu9Z9B042UH',
      callbackURL:'http://localhost:3000/api/auth/twitter/callback',
      userProfileURL: 'https://api.twitter.com/1.1/account/verify_credentials.json?include_email=true',
    },
  ethereal: {
    username: 'jalon.cummings@ethereal.email',
    password: 'VySFMMen5kMny8atcK',
    host: 'smtp.ethereal.email',
    port: 587,
  }

  };

