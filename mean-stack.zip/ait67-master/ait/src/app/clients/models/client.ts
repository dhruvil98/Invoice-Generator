export class Client {
    _id: string;
    firstName: string;
    lastName: string;
    email: string;
}
